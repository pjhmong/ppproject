
library(TTR)

Data_2014<-read.csv("Pollution_Data/3차전처리_경기도_년도_월달일/3.연도별month/pollution_2014_month.csv")
Data_2015<-read.csv("Pollution_Data/3차전처리_경기도_년도_월달일/3.연도별month/pollution_2015_month.csv")
Data_2016<-read.csv("Pollution_Data/3차전처리_경기도_년도_월달일/3.연도별month/pollution_2016_month.csv")

Data<-Data_2014
Data<-rbind(Data,Data_2015)
Data<-rbind(Data,Data_2016)
Data<-Data[-c(1:6)]
rm(Data_2014,Data_2015,Data_2016)

Data_2017<-read.csv("2017_1.csv")
Data_2017<-Data_2017[c(4,9)]

day<-substr(Data_2017$측정일시,1,6)

Data_2017$측정일시<-day

Data_2017<-data.frame(
  
  aggregate(PM10 ~ 측정일시,Data_2017,mean)
  
)

Data_2017<-Data_2017[2]

Data<-rbind(Data,Data_2017)

PM10_Data<-ts(Data,frequency = 12,start = c(2014,01), end = c(2017,03))
PM10_Data

write.csv(PM10_Data,"2014~2017_PM10_시계열 데이터 분석 기반자료.csv")
