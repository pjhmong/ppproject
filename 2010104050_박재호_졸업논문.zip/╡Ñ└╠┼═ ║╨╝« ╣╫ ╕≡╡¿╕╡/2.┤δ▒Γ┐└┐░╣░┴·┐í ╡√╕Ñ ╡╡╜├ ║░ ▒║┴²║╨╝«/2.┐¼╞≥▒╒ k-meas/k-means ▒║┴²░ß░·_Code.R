Data<-read.csv("군집분석 지역자료.csv")
Data<-Data[,-c(1,3,5:6)]

attach(Data)
x=Data[,2:3]
dx=round(dist(x),digits=2)
matrix
dx
D2=dist(x,method = "manhattan")
D2

hc1=hclust(dist(x)^2,method="single")

cl.num=3
colnames(x) = c("NO2","PM10")

hc1.result=cutree(hc1,k=cl.num)
#plot(x,pch=hc1.result)
#text(x,labels=지역,adj=0,cex=0.5,main="single")


Data_k=kmeans(x,center=3)
attributes(Data_k)
Data_k$cluster

clus=cbind(지역,x,Data_k$cluster)
clus1=clus[(clus[,4]==1),]
clus1
clus2=clus[(clus[,4]==2),]
clus2
clus3=clus[(clus[,4]==3),]
clus3

kc=table(Data_k$cluster)
kc
plot(x,pch=Data_k$cluster,col=Data_k$cluster,main="경기도 도시별 k-means 군집분석 결과")
text(x,labels = 지역,adj=0,cex=1.5)
