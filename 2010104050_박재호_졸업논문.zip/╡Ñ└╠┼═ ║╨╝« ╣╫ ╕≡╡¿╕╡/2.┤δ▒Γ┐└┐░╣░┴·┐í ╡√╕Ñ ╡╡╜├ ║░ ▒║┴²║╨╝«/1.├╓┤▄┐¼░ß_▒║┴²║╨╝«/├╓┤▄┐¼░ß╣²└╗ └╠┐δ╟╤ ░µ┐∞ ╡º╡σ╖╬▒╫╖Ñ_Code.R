Data<-read.csv("군집분석 지역자료.csv")
#Data<-Data[,-c[1]]

colnames(Data)<-c("Level","지역","O3","NO2","SO2","CO","PM10")

Data$Level<-1


for(i in 1:30){
  
  
  if(Data[i,3] > 0.04){
      
    Data[i,1] <- Data[i,1] + 1
      
  }
  if(Data[i,4] > 0.03){
    
    Data[i,1] <- Data[i,1] + 1
    
  }
  if(Data[i,5] > 0.006){
    
    Data[i,1] <- Data[i,1] + 1
    
  }
  if(Data[i,6] > 0.6){
    
    Data[i,1] <- Data[i,1] + 1
    
  }
  if(Data[i,7] > 50){
    
    Data[i,1] <- Data[i,1] + 1
    
  }
  
}

Data$Level<-as.factor(Data$Level)

attach(Data)
x=Data[,3:7]
dx=round(dist(x),digits=2)
matrix
dx
D2=dist(x,method = "manhattan")
D2

hc1=hclust(dist(x)^2, method="single")
plot(hc1,labels=지역,hang=-1,main="2014~2016 경기도 지역별 대기오염물질 군집분석")
