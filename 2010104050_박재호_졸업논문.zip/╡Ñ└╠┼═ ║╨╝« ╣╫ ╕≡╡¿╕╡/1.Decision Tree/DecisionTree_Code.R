
#install.packages("party")
#install.packages("caret")
library(party)
library(caret)

DecisionTree_Data<-read.csv("decisionTree_Data.csv")
DecisionTree_Data<-DecisionTree_Data[c(2:7)]

DecisionTree_Data$Date<-1


for(i in 2:6){
  
  if(i == 2){
    waring_Level<-0.06
  }
  if(i == 3){
    waring_Level<-0.8
  }
  if(i == 4){
    waring_Level<-0.05
  }
  if(i == 5){
    waring_Level<-0.03
  }
  if(i == 6){
    
    waring_Level<-80
  }
  
  for(j in 1:1096){
    
    if(DecisionTree_Data[j,i]>waring_Level){
      
      DecisionTree_Data[j,1]<-DecisionTree_Data[j,1]+1
      
    }
      
  }
  
  
}
DecisionTree_Data$Date<-as.factor(DecisionTree_Data$Date)

set.seed(1000)
intrain<-createDataPartition(y=DecisionTree_Data$Date, p=0.7, list=FALSE)
train<-DecisionTree_Data[intrain,]
test<-DecisionTree_Data[-intrain,]


air_Ctree<-ctree(Date~., data = train)
plot(air_Ctree)

partyPred<-predict(air_Ctree,test)

confusionMatrix(partyPred, test$Date)

