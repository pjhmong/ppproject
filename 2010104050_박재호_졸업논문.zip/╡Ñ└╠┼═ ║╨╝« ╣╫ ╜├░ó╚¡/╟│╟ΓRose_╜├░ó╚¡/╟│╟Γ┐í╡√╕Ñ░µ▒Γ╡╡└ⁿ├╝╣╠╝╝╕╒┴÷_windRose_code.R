
value1<-read.csv("Integrated_Data/1.통합_hour/integrated_동두천.csv",stringsAsFactors = FALSE)
value2<-read.csv("Integrated_Data/1.통합_hour/integrated_수원.csv",stringsAsFactors = FALSE)
value3<-read.csv("Integrated_Data/1.통합_hour/integrated_양평.csv",stringsAsFactors = FALSE)
value4<-read.csv("Integrated_Data/1.통합_hour/integrated_이천.csv",stringsAsFactors = FALSE)
value5<-read.csv("Integrated_Data/1.통합_hour/integrated_파주.csv",stringsAsFactors = FALSE)


A_value<-value1[c(2,10)]
B_value<-value2[c(2,10)]
C_value<-value3[c(2,10)]
D_value<-value4[c(2,10)]
E_value<-value5[c(2,10)]

setdata<-merge(x = A_value, y = B_value, by = "측정일시")    

setdata[,"풍향1"]=apply(setdata[c(2,3)], MARGIN = 1, FUN="mean")

setdata<-data.frame(setdata[1],setdata[4])

setdata<-merge(x = setdata, y = C_value, by = "측정일시")    

setdata[,"풍향2"] =apply(setdata[c(2,3)], MARGIN = 1, FUN="mean")

setdata<-data.frame(setdata[1],setdata[4])

setdata<-merge(x = setdata, y = D_value, by = "측정일시")    

setdata[,"풍향3"] =apply(setdata[c(2,3)], MARGIN = 1, FUN="mean")

setdata<-data.frame(setdata[1],setdata[4])

setdata<-merge(x = setdata, y = E_value, by = "측정일시")    

setdata["풍향"] =apply(setdata[c(2,3)], MARGIN = 1, FUN="mean")

setdata<-data.frame(setdata[1],setdata[4])

temp<-setdata$측정일시

year<-substr(temp,1,4)
month<-substr(temp,5,7)
day<-substr(temp,8,10)


temp<-paste(year,month,sep="")
temp<-paste(temp,day,sep="")

setdata$측정일시<-temp
colnames(setdata)<-c("측정일시","풍향.16방위.")

setdata<-data.frame(
  
  aggregate(풍향.16방위. ~ 측정일시,setdata,mean)
  
)

PM10_Data_1<-read.csv("Pollution_Data/3차전처리_경기도_년도_월달일/2.연도별day/pollution_2014_day.csv")
PM10_Data_2<-read.csv("Pollution_Data/3차전처리_경기도_년도_월달일/2.연도별day/pollution_2015_day.csv")
PM10_Data_3<-read.csv("Pollution_Data/3차전처리_경기도_년도_월달일/2.연도별day/pollution_2016_day.csv")

PM10_Data<-rbind(PM10_Data_1,PM10_Data_2)
PM10_Data<-rbind(PM10_Data,PM10_Data_3)

setdata<-merge(x = setdata, y = PM10_Data, by = "측정일시")
setdata<-data.frame(setdata[1],setdata[2],setdata[8])

require(ggplot2)
require(RColorBrewer)

plot.windrose <- function(data,
                          spd,
                          dir,
                          spdres = 2,
                          dirres = 30,
                          spdmin = 2,
                          spdmax = 20,
                          spdseq = NULL,
                          palette = "YlGnBu",
                          countmax = NA,
                          debug = 0){
  
  if (is.numeric(spd) & is.numeric(dir)){
    data <- data.frame(spd = spd,
                       dir = dir)
    spd = "spd"
    dir = "dir"
  } else if (exists("data")){
  }  
  
  n.in <- NROW(data)
  dnu <- (is.na(data[[spd]]) | is.na(data[[dir]]))
  data[[spd]][dnu] <- NA
  data[[dir]][dnu] <- NA
  
  if (missing(spdseq)){
    spdseq <- seq(spdmin,spdmax,spdres)
  } else {
    if (debug >0){
      cat("Using custom speed bins \n")
    }
  }
  n.spd.seq <- length(spdseq)
  n.colors.in.range <- n.spd.seq - 1
  
  spd.colors <- colorRampPalette(brewer.pal(min(max(3,
                                                    n.colors.in.range),
                                                min(9,
                                                    n.colors.in.range)),                                               
                                            palette))(n.colors.in.range)
  
  if (max(data[[spd]],na.rm = TRUE) > spdmax){    
    spd.breaks <- c(spdseq,
                    max(data[[spd]],na.rm = TRUE))
    spd.labels <- c(paste(c(spdseq[1:n.spd.seq-1]),
                          '-',
                          c(spdseq[2:n.spd.seq])),
                    paste(spdmax,
                          "-",
                          max(data[[spd]],na.rm = TRUE)))
    spd.colors <- c(spd.colors, "grey50")
  } else{
    spd.breaks <- spdseq
    spd.labels <- paste(c(spdseq[1:n.spd.seq-1]),
                        '-',
                        c(spdseq[2:n.spd.seq]))    
  }
  data$spd.binned <- cut(x = data[[spd]],
                         breaks = spd.breaks,
                         labels = spd.labels,
                         ordered_result = TRUE)
  data. <- na.omit(data)
  
  dir.breaks <- c(-dirres/2,
                  seq(dirres/2, 360-dirres/2, by = dirres),
                  360+dirres/2)  
  dir.labels <- c(paste(360-dirres/2,"-",dirres/2),
                  paste(seq(dirres/2, 360-3*dirres/2, by = dirres),
                        "-",
                        seq(3*dirres/2, 360-dirres/2, by = dirres)),
                  paste(360-dirres/2,"-",dirres/2))
  
  dir.binned <- cut(data[[dir]],
                    breaks = dir.breaks,
                    ordered_result = TRUE)
  levels(dir.binned) <- dir.labels
  data$dir.binned <- dir.binned
  
  if (debug>0){    
    cat(dir.breaks,"\n")
    cat(dir.labels,"\n")
    cat(levels(dir.binned),"\n")       
  }  
  
  if(packageVersion("ggplot2") > "2.2"){    
    data$spd.binned = with(data, factor(spd.binned, levels = rev(levels(spd.binned))))
    spd.colors = rev(spd.colors)
  }
  
  p.windrose <- ggplot(data = data,
                       aes(x = dir.binned,
                           fill = spd.binned)) +
    geom_bar() + 
    scale_x_discrete(drop = FALSE,
                     labels = waiver()) +
    coord_polar(start = -((dirres/2)/360) * 2*pi) +
    scale_fill_manual(name = "PM10(㎍/m³)", 
                      values = spd.colors,
                      drop = FALSE) +
    theme(axis.title.x = element_blank())
  
  if (!is.na(countmax)){
    p.windrose <- p.windrose +
      ylim(c(0,countmax))
  }
  
  print(p.windrose)  
  
  return(p.windrose)
}


data.in <- setdata


p0 <- plot.windrose(spd = data.in$PM10,dir = data.in$풍향.16방위.,spdseq = c(0,30,55,80,105,125,150))
