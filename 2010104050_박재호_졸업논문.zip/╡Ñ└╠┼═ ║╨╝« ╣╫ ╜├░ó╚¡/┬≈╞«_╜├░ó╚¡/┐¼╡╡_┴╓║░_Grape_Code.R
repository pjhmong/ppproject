
month_Data_2014=read.csv("Pollution_Data/3차전처리_경기도_년도_월달일/2.연도별day/pollution_2014_day.csv",stringsAsFactors = FALSE)
month_Data_2015=read.csv("Pollution_Data/3차전처리_경기도_년도_월달일/2.연도별day/pollution_2015_day.csv",stringsAsFactors = FALSE)
month_Data_2016=read.csv("Pollution_Data/3차전처리_경기도_년도_월달일/2.연도별day/pollution_2016_day.csv",stringsAsFactors = FALSE)

#### 14, 15, 16년도 no2, o3 데이터를 요일별 평균으로 정리#############

week_DataList<-list()
week_DataList[[1]]<-month_Data_2014
week_DataList[[2]]<-month_Data_2015
week_DataList[[3]]<-month_Data_2016

# 14년도 1월 1일 -> 수요일, 365일
# 15년도 1월 1일 -> 목요일, 365일
# 16년도 1월 1일 -> 금요일, 366일

for(i in 1:3){
  
  trasform_week<-data.frame(week_DataList[[i]])
  week<-trasform_week$측정일시
  
  if(i==1){
    
    for(j in seq(1,364, by = 7)){
      
      week[j]<-"수요일"
      week[j+1]<-"목요일"
      week[j+2]<-"금요일"
      week[j+3]<-"토요일"
      week[j+4]<-"일요일"
      week[j+5]<-"월요일"
      week[j+6]<-"화요일"
      
    }
  
    week[365]<-"수요일"
    
  }
  if(i == 2){
    
    for(j in seq(1,364, by = 7)){
      
      week[j]<-"목요일"
      week[j+1]<-"금요일"
      week[j+2]<-"토요일"
      week[j+3]<-"일요일"
      week[j+4]<-"월요일"
      week[j+5]<-"화요일"
      week[j+6]<-"수요일"
      
    }
    week[365]<-"목요일"
  }
  if(i == 3){
    
    for(j in seq(1,364, by = 7)){
      
      week[j]<-"금요일"
      week[j+1]<-"토요일"
      week[j+2]<-"일요일"
      week[j+3]<-"월요일"
      week[j+4]<-"화요일"
      week[j+5]<-"수요일"
      week[j+6]<-"목요일"
      
    }
    week[365]<-"금요일"
    week[366]<-"토요일"
    
  }
  
  trasform_week$측정일시<-week
  
  trasform_week<-data.frame(
    
    aggregate(O3 ~ 측정일시,trasform_week,mean),
    aggregate(NO2 ~ 측정일시,trasform_week,mean),
    aggregate(SO2 ~ 측정일시,trasform_week,mean),
    aggregate(CO ~ 측정일시,trasform_week,mean),
    aggregate(PM10 ~ 측정일시,trasform_week,mean)
    
  )
  
  trasform_week<-trasform_week[c(1,2,4,6,8,10)]
  # 금 목 수 월 일 토 화
  trasform_week<-trasform_week[c(4,7,3,2,1,6,5),]
  # 월 화 수 목 금 토 일
  rownames(trasform_week)<- NULL
  
  week_DataList[[i]]<-trasform_week
}

total_DataList<-data.frame(week_DataList[1])
total_DataList<- rbind(total_DataList, data.frame(week_DataList[2]))
total_DataList<- rbind(total_DataList, data.frame(week_DataList[3]))

total_DataList<-data.frame(
  
  aggregate(O3 ~ 측정일시,total_DataList,mean),
  aggregate(NO2 ~ 측정일시,total_DataList,mean),
  aggregate(SO2 ~ 측정일시,total_DataList,mean),
  aggregate(CO ~ 측정일시,total_DataList,mean),
  aggregate(PM10 ~ 측정일시,total_DataList,mean)
  
)

total_DataList<-total_DataList[c(1,2,4,6,8,10)]


rm(month_Data_2014,month_Data_2015,month_Data_2016,trasform_week)



########################2014년도 주별 O3 Grape########################################

ggplot(data.frame(week_DataList[1]), aes(x=측정일시 ,y=O3, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014년 주별 O3 Grape")

########################2014년도 주별 NO2 Grape########################################

ggplot(data.frame(week_DataList[1]), aes(x=측정일시 ,y=NO2, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014년 주별 NO2 Grape")

########################2014년도 주별 SO2 Grape########################################

ggplot(data.frame(week_DataList[1]), aes(x=측정일시 ,y = SO2, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014년 주별 SO2 Grape")

########################2014년도 주별 CO Grape########################################

ggplot(data.frame(week_DataList[1]), aes(x=측정일시 ,y = CO, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014년 주별 CO Grape")

########################2014년도 주별 PM10 Grape########################################

ggplot(data.frame(week_DataList[1]), aes(x=측정일시 ,y = PM10, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014년 주별 PM10 Grape")

########################2015년도 주별 O3 Grape########################################

ggplot(data.frame(week_DataList[2]), aes(x=측정일시 ,y=O3, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2015년 주별 O3 Grape")

########################2015년도 주별 NO2 Grape########################################

ggplot(data.frame(week_DataList[2]), aes(x=측정일시 ,y=NO2, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2015년 주별 NO2 Grape")

########################2015년도 주별 SO2 Grape########################################

ggplot(data.frame(week_DataList[2]), aes(x=측정일시 ,y = SO2, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2015년 주별 SO2 Grape")

########################2015년도 주별 CO Grape########################################

ggplot(data.frame(week_DataList[2]), aes(x=측정일시 ,y = CO, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2015년 주별 CO Grape")

########################2015년도 주별 PM10 Grape########################################

ggplot(data.frame(week_DataList[2]), aes(x=측정일시 ,y = PM10, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2015년 주별 PM10 Grape")

########################2016년도 주별 O3 Grape########################################

ggplot(data.frame(week_DataList[3]), aes(x=측정일시 ,y=O3, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2016년 주별 O3 Grape")

########################2016년도 주별 NO2 Grape########################################

ggplot(data.frame(week_DataList[3]), aes(x=측정일시 ,y=NO2, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2016년 주별 NO2 Grape")

########################2016년도 주별 SO2 Grape########################################

ggplot(data.frame(week_DataList[3]), aes(x=측정일시 ,y = SO2, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2016년 주별 SO2 Grape")

########################2016년도 주별 CO Grape########################################

ggplot(data.frame(week_DataList[3]), aes(x=측정일시 ,y = CO, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2016년 주별 CO Grape")

########################2016년도 주별 PM10 Grape########################################

ggplot(data.frame(week_DataList[3]), aes(x=측정일시 ,y = PM10, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2016년 주별 PM10 Grape")


########################2014 ~ 2016년도 주별 O3 Grape########################################

ggplot(total_DataList, aes(x=측정일시 ,y=O3, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014 ~ 2016년도 주별 O3 Grape")

########################2014 ~ 2016년도 주별 NO2 Grape########################################

ggplot(total_DataList, aes(x=측정일시 ,y=NO2, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014 ~ 2016년도 주별 NO2 Grape")

########################2014 ~ 2016년도 주별 SO2 Grape########################################

ggplot(total_DataList, aes(x=측정일시 ,y = SO2, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014 ~ 2016년도 주별 SO2 Grape")

########################2014 ~ 2016년도 주별 CO Grape########################################

ggplot(total_DataList, aes(x=측정일시 ,y = CO, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014 ~ 2016년도 주별 CO Grape")

########################2014 ~ 2016년도 주별 PM10 Grape########################################

ggplot(total_DataList, aes(x=측정일시 ,y = PM10, group = 1))+
  scale_x_discrete(limits=c("월요일", "화요일", "수요일","목요일","금요일","토요일","일요일"))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014 ~ 2016년 주별 PM10 Grape")





