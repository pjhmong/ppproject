
month_Data_2014=read.csv("Pollution_Data/3차전처리_경기도_년도_월달일/3.연도별month/pollution_2014_month.csv",stringsAsFactors = FALSE)
month_Data_2015=read.csv("Pollution_Data/3차전처리_경기도_년도_월달일/3.연도별month/pollution_2015_month.csv",stringsAsFactors = FALSE)
month_Data_2016=read.csv("Pollution_Data/3차전처리_경기도_년도_월달일/3.연도별month/pollution_2016_month.csv",stringsAsFactors = FALSE)

pollution_DataList_2014<-list() #연도별 ,요소별 터대기오염물질 데이터
pollution_DataList_2015<-list()
pollution_DataList_2016<-list()

########################################################################################
pollution_Data<-data.frame(month_Data_2014$측정일시,month_Data_2014$SO2)
colnames(pollution_Data)<-c("월","SO2")
pollution_DataList_2014[[1]]<-pollution_Data
    
pollution_Data<-data.frame(month_Data_2014$측정일시,month_Data_2014$CO)
colnames(pollution_Data)<-c("월","CO")
pollution_DataList_2014[[2]]<-pollution_Data
    
pollution_Data<-data.frame(month_Data_2014$측정일시,month_Data_2014$O3)
colnames(pollution_Data)<-c("월","O3")
pollution_DataList_2014[[3]]<-pollution_Data
    
pollution_Data<-data.frame(month_Data_2014$측정일시,month_Data_2014$NO2)
colnames(pollution_Data)<-c("월","NO2")
pollution_DataList_2014[[4]]<-pollution_Data
    
pollution_Data<-data.frame(month_Data_2014$측정일시,month_Data_2014$PM10)
colnames(pollution_Data)<-c("월","PM10")
pollution_DataList_2014[[5]]<-pollution_Data
########################################################################################
pollution_Data<-data.frame(month_Data_2015$측정일시,month_Data_2015$SO2)
colnames(pollution_Data)<-c("월","SO2")
pollution_DataList_2015[[1]]<-pollution_Data

pollution_Data<-data.frame(month_Data_2015$측정일시,month_Data_2015$CO)
colnames(pollution_Data)<-c("월","CO")
pollution_DataList_2015[[2]]<-pollution_Data

pollution_Data<-data.frame(month_Data_2015$측정일시,month_Data_2015$O3)
colnames(pollution_Data)<-c("월","O3")
pollution_DataList_2015[[3]]<-pollution_Data

pollution_Data<-data.frame(month_Data_2015$측정일시,month_Data_2015$NO2)
colnames(pollution_Data)<-c("월","NO2")
pollution_DataList_2015[[4]]<-pollution_Data

pollution_Data<-data.frame(month_Data_2015$측정일시,month_Data_2015$PM10)
colnames(pollution_Data)<-c("월","PM10")
pollution_DataList_2015[[5]]<-pollution_Data
########################################################################################
pollution_Data<-data.frame(month_Data_2016$측정일시,month_Data_2016$SO2)
colnames(pollution_Data)<-c("월","SO2")
pollution_DataList_2016[[1]]<-pollution_Data

pollution_Data<-data.frame(month_Data_2016$측정일시,month_Data_2016$CO)
colnames(pollution_Data)<-c("월","CO")
pollution_DataList_2016[[2]]<-pollution_Data

pollution_Data<-data.frame(month_Data_2016$측정일시,month_Data_2016$O3)
colnames(pollution_Data)<-c("월","O3")
pollution_DataList_2016[[3]]<-pollution_Data

pollution_Data<-data.frame(month_Data_2016$측정일시,month_Data_2016$NO2)
colnames(pollution_Data)<-c("월","NO2")
pollution_DataList_2016[[4]]<-pollution_Data

pollution_Data<-data.frame(month_Data_2016$측정일시,month_Data_2016$PM10)
colnames(pollution_Data)<-c("월","PM10")
pollution_DataList_2016[[5]]<-pollution_Data

remove(pollution_Data)

########################################################################################

temp1<-month_Data_2014
temp2<-month_Data_2015
temp3<-month_Data_2016

temp1$측정일시<-temp2$측정일시
temp3$측정일시<-temp2$측정일시

total_Data_year<-rbind(temp1,temp2)
total_Data_year<-rbind(total_Data_year,temp3)

total_Data_year<-data.frame(
  
  aggregate(SO2 ~ 측정일시,total_Data_year,mean),
  aggregate(CO ~ 측정일시,total_Data_year,mean),
  aggregate(O3 ~ 측정일시,total_Data_year,mean),
  aggregate(NO2 ~ 측정일시,total_Data_year,mean),
  aggregate(PM10 ~ 측정일시,total_Data_year,mean)
  
)

total_Data_year<-total_Data_year[c(2,4,6,8,10)]

total_Data_year<-data.frame(c("01월","02월","03월","04월","05월","06월","07월","08월","09월","10월","11월","12월"), total_Data_year)
colnames(total_Data_year)<-c("월","SO2","CO","O3","NO2","PM10")
remove(temp1,temp2,temp3)



#install.packages("ggplot2")
#library(ggplot2) 

#########################2014_SO2#######################################

ggplot(data.frame(pollution_DataList_2014[1]), aes(x=월 ,y=SO2, group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014년 경기도 월별 SO2 수치")

########################2014_CO########################################

ggplot(data.frame(pollution_DataList_2014[2]), aes(x=월 ,y=CO,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014년 경기도 월별 CO 수치")

########################2014_O3########################################

ggplot(data.frame(pollution_DataList_2014[3]), aes(x=월 ,y=O3,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014년 경기도 월별 O3 수치")

########################2014_NO2########################################

ggplot(data.frame(pollution_DataList_2014[4]), aes(x=월 ,y=NO2,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014년 경기도 월별 NO2 수치")

########################2014_PM10########################################

ggplot(data.frame(pollution_DataList_2014[5]), aes(x=월 ,y=PM10,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014년 경기도 월별 PM10 수치")

#########################2015_SO2#######################################

ggplot(data.frame(pollution_DataList_2015[1]), aes(x=월 ,y=SO2, group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2015년 경기도 월별 SO2 수치")

########################2015_CO########################################

ggplot(data.frame(pollution_DataList_2015[2]), aes(x=월 ,y=CO,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2015년 경기도 월별 CO 수치")

########################2015_O3########################################

ggplot(data.frame(pollution_DataList_2015[3]), aes(x=월 ,y=O3,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2015년 경기도 월별 O3 수치")

########################2015_NO2########################################

ggplot(data.frame(pollution_DataList_2015[4]), aes(x=월 ,y=NO2,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2015년 경기도 월별 NO2 수치")

########################2015_PM10########################################

ggplot(data.frame(pollution_DataList_2015[5]), aes(x=월 ,y=PM10,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2015년 경기도 월별 PM10 수치")

#########################2016_SO2#######################################

ggplot(data.frame(pollution_DataList_2016[1]), aes(x=월 ,y=SO2, group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2016년 경기도 월별 SO2 수치")

########################2016_CO########################################

ggplot(data.frame(pollution_DataList_2016[2]), aes(x=월 ,y=CO,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2016년 경기도 월별 CO 수치")

########################2016_O3########################################

ggplot(data.frame(pollution_DataList_2016[3]), aes(x=월 ,y=O3,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2016년 경기도 월별 O3 수치")

########################2016_NO2########################################

ggplot(data.frame(pollution_DataList_2016[4]), aes(x=월 ,y=NO2,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2016년 경기도 월별 NO2 수치")

########################2016_PM10########################################

ggplot(data.frame(pollution_DataList_2016[5]), aes(x=월 ,y=PM10,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2016년 경기도 월별 PM10 수치")


#########################total_SO2#######################################

ggplot(total_Data_year, aes(x= 월 ,y=SO2, group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014~2016년 경기도 월별 SO2 수치")

########################total_CO########################################

ggplot(total_Data_year, aes(x=월 ,y=CO,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014~2016년 경기도 월별 CO 수치")

########################total_O3########################################

ggplot(total_Data_year, aes(x=월 ,y=O3,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014~2016년 경기도 월별 O3 수치")

########################total_NO2########################################

ggplot(total_Data_year, aes(x=월 ,y=NO2,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014~2016년 경기도 월별 NO2 수치")

########################total_PM10########################################

ggplot(total_Data_year, aes(x=월 ,y=PM10,group = 1))+
  geom_line(color="black", size=1) + 
  geom_point(color="black", size=3) +
  ggtitle("2014~2016년 경기도 월별 PM10 수치")

